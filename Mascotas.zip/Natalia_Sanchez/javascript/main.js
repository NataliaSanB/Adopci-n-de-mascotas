//const  nombre=document.getElementById("name")
//const  rut=document.getElementById("rut")
//const  correo=document.getElementById("email")
//const  edad=document.getElementById("edad")
//const  fecha_nacimiento=document.getElementById("fecha")

/* Llamando funciones del contador falso*/ 
jQuery(document).ready(function() {
	function count($this){
		var current = parseInt($this.html(), 10);
		current = current + 1; /* icrementable en 1 */

		$this.html(++current);
		if(current > $this.data('count')){
			$this.html($this.data('count'));
		} else {
			setTimeout(function(){count($this)}, 50);
		}
	}

	jQuery(".stat-count").each(function() {
	  jQuery(this).data('count', parseInt(jQuery(this).html(), 10));
	  jQuery(this).html('0');
	  count(jQuery(this));
	});

	var inputRut = document.getElementById('rut');
	inputRut.onblur = function() {
		var isCheck = checkRut(this)
		console.log(isCheck)
		if(isCheck != undefined) {
			alert("RUT Inválido")
		}				
	  }
});


/* Pasar de miniscula a mayuscula */
function mayuscula(e){
    e.value = e.value.toUpperCase();
}


/* Validacion del Rut*/

function checkRut(rut) {
    var valor = rut.value.replace('.','');
    valor = valor.replace('-','');
    cuerpo = valor.slice(0,-1);
    dv = valor.slice(-1).toUpperCase();
    
    rut.value = cuerpo + '-'+ dv
    
    if(cuerpo.length < 7) { rut.setCustomValidity("RUT Incompleto"); return false;}
    suma = 0;
    multiplo = 2;
    
    for(i=1;i<=cuerpo.length;i++) {
        index = multiplo * valor.charAt(cuerpo.length - i);
        suma = suma + index;
        if(multiplo < 7) { multiplo = multiplo + 1; } else { multiplo = 2; }
  
    }
    dvEsperado = 11 - (suma % 11);
    dv = (dv == 'K')?10:dv;
    dv = (dv == 0)?11:dv;
    
    if(dvEsperado != dv) { rut.setCustomValidity("RUT Inválido"); return false; }
    
    rut.setCustomValidity('');
}



/* Validar mail*/
function validarEmail(valor) {
	if (/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(valor)){
	 alert("La dirección de email " + valor + " es correcta!.");
	} else {
	 alert("La dirección de email es incorrecta!.");
	}
  }


